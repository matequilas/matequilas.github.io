<footer class="main-footer">
  <div class="pull-right hidden-xs">
    <b>Version</b> 2.4.0
  </div>
  <strong>Copyright &copy; 2014-2016 <a href="https://adminlte.io">Almsaeed Studio</a>.</strong> All rights
  reserved.
</footer>


</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="js/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.dataTables.min.js"></script>
<script src="js/dataTables.bootstrap.min.js"></script>

<!-- SlimScroll -->
<script src="js/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="js/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="js/adminlte.min.js"></script>

<script src="js/sweetalert2.min.js"></script>

<script src="js/admin-ajax.js?v=0.0.22"></script>
<script src="js/bootstrap-datepicker.min.js"></script>
<script src="js/select2.full.min.js"></script>
<script src="js/bootstrap-timepicker.min.js"></script>
<script src="js/fontawesome-iconpicker.min.js"></script>

<script src="js/raphael.min.js"></script>
<script src="js/morris.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="js/demo.js"></script>
<script src="js/login-ajax.js"></script>
<script src="js/icheck.min.js"></script>
<script src="../js/cotizador.js"></script>
<script src="js/app.js?v=0.0.8"></script>
</body>
</html>