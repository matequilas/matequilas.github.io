<?php include_once 'includes/templates/header.php'; ?>
<?php include_once 'includes/templates/invitados.php'; ?>

<?php include_once 'includes/templates/footer.php'; ?>
